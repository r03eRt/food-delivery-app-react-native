const profile = require("../assets/images/profile.png")

export default {
    profile,
}