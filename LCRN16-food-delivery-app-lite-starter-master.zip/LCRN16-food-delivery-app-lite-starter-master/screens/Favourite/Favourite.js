import React from 'react';
import {
    View,
} from 'react-native';

const Favourite = () => {
    return (
        <View>
        </View>
    )
}

export default Favourite