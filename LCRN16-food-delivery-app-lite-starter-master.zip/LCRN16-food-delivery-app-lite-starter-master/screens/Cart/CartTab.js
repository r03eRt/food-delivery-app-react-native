import React from 'react';
import {
    View,
    Text
} from 'react-native';

const CartTab = () => {
    return (
        <View>
        </View>
    )
}

export default CartTab