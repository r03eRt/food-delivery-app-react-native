import React from 'react';
import {
    View,
} from 'react-native';

const Search = () => {
    return (
        <View>
        </View>
    )
}

export default Search